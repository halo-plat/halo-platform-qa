# Halo Test Lab GUI launcher (Windows PowerShell)
if (!(Test-Path ".venv")) {
  Write-Host "Creating venv..."
  python -m venv .venv
}
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt | Out-Host
python -m halo_test_lab.gui
