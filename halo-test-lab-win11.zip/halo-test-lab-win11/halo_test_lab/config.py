from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import yaml

@dataclass(frozen=True)
class EnvConfig:
    name: str
    base_url: str
    client_id: str
    api_key: str
    timeout_s: int = 30

def load_env_config(path: Path) -> EnvConfig:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    return EnvConfig(
        name=data.get("name", path.stem),
        base_url=data["base_url"],
        client_id=data.get("client_id", ""),
        api_key=data.get("api_key", ""),
        timeout_s=int(data.get("timeout_s", 30)),
    )
