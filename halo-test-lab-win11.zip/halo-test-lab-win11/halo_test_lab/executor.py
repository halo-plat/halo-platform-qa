from __future__ import annotations
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

@dataclass
class RunResult:
    name: str
    exit_code: int
    stdout_path: Path
    stderr_path: Path
    artifact_paths: List[Path]

def _run(cmd: List[str], cwd: Path, out_dir: Path, name: str) -> RunResult:
    out_dir.mkdir(parents=True, exist_ok=True)
    stdout_path = out_dir / f"{name}.stdout.log"
    stderr_path = out_dir / f"{name}.stderr.log"

    with stdout_path.open("w", encoding="utf-8") as so, stderr_path.open("w", encoding="utf-8") as se:
        p = subprocess.Popen(cmd, cwd=str(cwd), stdout=so, stderr=se, text=True)
        code = p.wait()

    return RunResult(name=name, exit_code=code, stdout_path=stdout_path, stderr_path=stderr_path, artifact_paths=[stdout_path, stderr_path])

def run_pytest(repo_root: Path, out_dir: Path, marker: str = "e2e") -> RunResult:
    junit = out_dir / "pytest-junit.xml"
    cmd = [sys.executable, "-m", "pytest", "-m", marker, "--junitxml", str(junit), "-q"]
    rr = _run(cmd, cwd=repo_root, out_dir=out_dir, name="pytest")
    rr.artifact_paths.append(junit)
    return rr

def run_k6(repo_root: Path, out_dir: Path, script: Path) -> RunResult:
    summary = out_dir / "k6-summary.json"
    cmd = ["k6", "run", str(script), "--summary-export", str(summary)]
    rr = _run(cmd, cwd=repo_root, out_dir=out_dir, name="k6")
    rr.artifact_paths.append(summary)
    return rr

def write_run_manifest(out_dir: Path, manifest: dict) -> Path:
    path = out_dir / "run-manifest.json"
    path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return path
