# Halo Test Lab (Win11) — GUI Orchestrator for Automated Testing

This repository provides a **Windows 11 desktop GUI** that orchestrates Halo Platform test automation:
- **Regression / E2E smoke** via `pytest` (CLI-first)
- **Performance & Load** via `k6` (CLI-first)
- Run manifests (build SHA, env, suites, timings), logs, and machine-readable outputs (JUnit/XML, JSON)

The GUI is intentionally *thin*: it does not "implement testing logic"; it **selects, runs, and reports** test suites
to keep the system repeatable and audit-friendly.

## 1) What you get
- `halo_test_lab/gui.py`: PySide6 GUI
- `halo_test_lab/executor.py`: subprocess runner for pytest/k6
- `configs/*.yaml`: environment profiles (staging/dev)
- `examples/tests`: example pytest suite
- `examples/k6`: example load script

## 2) Prerequisites (Win11)
- Python 3.11+ (recommended)
- Optional: Chocolatey or winget (allowed in your environment)

### Install Python deps
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

### Install k6 (for load/perf)
Using winget:
```powershell
winget install --id k6.k6 -e
```
Or Chocolatey:
```powershell
choco install k6 -y
```

(Optionally) install Allure CLI if you want HTML reports from pytest results.

## 3) Configure environments
Edit or add YAML files in `configs/`.

Example: `configs/staging.yaml`
- base_url: Halo API base URL
- api_key / client_id: tenant auth material
- timeouts and paths

## 4) Run the GUI
```powershell
.\run_gui.ps1
```

## 5) Suites (initial gates)
- **E2E Smoke**: `pytest -m e2e --junitxml ...`
- **NF Load (k6)**: `k6 run examples/k6/basic.js --summary-export ...`

Outputs go to: `runs/<timestamp>/`

## 6) Extending for Halo Platform
- Add new pytest tests under your QA repo and reference them as a suite.
- Add k6 scripts for endpoint-specific load profiles (ramp-up, break-point discovery).
- Wire “build SHA” from CI into the GUI by writing to `configs/build.json` (optional).

## Governance note
This tool is designed to map cleanly to STVP/RTM:
- Test cases should carry IDs (e.g., TC-CONV-001) in their names or markers.
- Runs produce evidence artifacts that can be archived.
